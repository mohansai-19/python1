import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import datetime, date
from collections import Counter
import json, csv
from booking_service import (validate_booking, find_conflict, next_booking_id, search_bookings, booking_summary)
from repository import load_bookings, save_bookings, import_csv, DB_PATH, SAMPLE_PATH, REPORTS_DIR

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
REPORTS = REPORTS_DIR
DB = DB_PATH
SAMPLE = SAMPLE_PATH
DATA.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)

BG = "#F3F6FB"
NAV = "#17243A"
ACCENT = "#4169E1"
WHITE = "#FFFFFF"
TEXT = "#1E293B"
MUTED = "#64748B"
GREEN = "#15966A"
RED = "#D94B58"

def load_data():
    return load_bookings()

def save_data(data):
    save_bookings(data)

def overlap(a, b, c, d):
    from booking_service import intervals_overlap
    return intervals_overlap(a, b, c, d)

class BookingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CampusBook | Classroom Resource Booking")
        self.geometry("1180x760")
        self.minsize(1000, 650)
        self.configure(bg=BG)
        self.bookings = load_data()
        self.current_page = None
        self.setup_style()
        self.build_shell()
        self.show_dashboard()

    def setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", background=WHITE, foreground=TEXT,
                        rowheight=34, fieldbackground=WHITE, borderwidth=0,
                        font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background="#E8EEF8",
                        foreground=TEXT, font=("Segoe UI", 10, "bold"), relief="flat")
        style.map("Treeview", background=[("selected", "#DCE7FF")],
                  foreground=[("selected", TEXT)])
        style.configure("TCombobox", padding=7, font=("Segoe UI", 10))
        style.configure("TEntry", padding=8, font=("Segoe UI", 10))

    def build_shell(self):
        self.sidebar = tk.Frame(self, bg=NAV, width=225)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar, text="◈  CAMPUSBOOK", bg=NAV, fg="white",
                 font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=22, pady=(28, 4))
        tk.Label(self.sidebar, text="RESOURCE MANAGEMENT", bg=NAV, fg="#9EADC4",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=24, pady=(0, 30))
        self.nav_button("▦   Dashboard", self.show_dashboard)
        self.nav_button("＋   New booking", self.show_add)
        self.nav_button("▤   All bookings", self.show_bookings)
        self.nav_button("⌕   Search bookings", self.show_search)
        self.nav_button("▥   Reports & analytics", self.show_reports)
        self.nav_button("⇩   Import sample data", self.import_sample)
        tk.Frame(self.sidebar, bg="#34435A", height=1).pack(fill="x", padx=20, pady=22)
        tk.Label(self.sidebar, text="CLASSROOM RESOURCE\nBOOKING SYSTEM",
                 bg=NAV, fg="#9EADC4", justify="left",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=23)
        self.main = tk.Frame(self, bg=BG)
        self.main.pack(side="right", fill="both", expand=True)

    def nav_button(self, label, command):
        btn = tk.Button(self.sidebar, text=label, command=command, anchor="w",
                        bg=NAV, fg="#E7EDF7", activebackground="#2A3C59",
                        activeforeground="white", relief="flat", bd=0,
                        font=("Segoe UI", 10, "bold"), padx=22, pady=13,
                        cursor="hand2")
        btn.pack(fill="x", padx=10, pady=2)

    def clear(self):
        for widget in self.main.winfo_children():
            widget.destroy()

    def header(self, title, subtitle):
        top = tk.Frame(self.main, bg=BG)
        top.pack(fill="x", padx=32, pady=(27, 18))
        tk.Label(top, text=title, bg=BG, fg=TEXT,
                 font=("Segoe UI", 23, "bold")).pack(anchor="w")
        tk.Label(top, text=subtitle, bg=BG, fg=MUTED,
                 font=("Segoe UI", 10)).pack(anchor="w", pady=(4, 0))

    def button(self, parent, text, command, color=ACCENT):
        return tk.Button(parent, text=text, command=command, bg=color, fg=WHITE,
                         activebackground=color, activeforeground=WHITE,
                         relief="flat", bd=0, padx=17, pady=10,
                         font=("Segoe UI", 10, "bold"), cursor="hand2")

    def card(self, parent, title, value, color):
        frame = tk.Frame(parent, bg=WHITE, highlightbackground="#E4EAF2",
                         highlightthickness=1)
        tk.Frame(frame, bg=color, height=4).pack(fill="x")
        tk.Label(frame, text=title.upper(), bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=18, pady=(15, 4))
        val = tk.Label(frame, text=str(value), bg=WHITE, fg=TEXT,
                       font=("Segoe UI", 25, "bold"))
        val.pack(anchor="w", padx=18, pady=(0, 16))
        return frame, val

    def show_dashboard(self):
        self.clear()
        self.header("Dashboard", "Welcome back. Here's your classroom resource overview.")
        stats = booking_summary(self.bookings)
        active = [b for b in self.bookings if b.get("status", "Approved") != "Cancelled"]
        cancelled = stats["cancelled"]
        cards = tk.Frame(self.main, bg=BG)
        cards.pack(fill="x", padx=32)
        for title, value, color in [
            ("Total bookings", len(self.bookings), ACCENT),
            ("Active bookings", len(active), GREEN),
            ("Cancelled", cancelled, RED),
            ("Classrooms & labs", len(set(b.get("room") for b in active)), "#8B5CF6")
        ]:
            c, _ = self.card(cards, title, value, color)
            c.pack(side="left", fill="both", expand=True, padx=(0, 12))
        panel = tk.Frame(self.main, bg=WHITE, highlightbackground="#E4EAF2",
                         highlightthickness=1)
        panel.pack(fill="both", expand=True, padx=32, pady=24)
        heading = tk.Frame(panel, bg=WHITE)
        heading.pack(fill="x", padx=20, pady=18)
        tk.Label(heading, text="Recent bookings", bg=WHITE, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(side="left")
        self.button(heading, "View all", self.show_bookings).pack(side="right")
        self.make_table(panel, height=10)
        tk.Label(self.main, text="Tip: Import sample data to explore the system with 35 demo records.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=34, pady=(0, 12))

    def make_table(self, parent, data=None, height=12):
        cols = ("id", "date", "time", "room", "type", "requester", "status")
        wrap = tk.Frame(parent, bg=WHITE)
        wrap.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        tree = ttk.Treeview(wrap, columns=cols, show="headings", height=height)
        headings = {"id":"ID", "date":"DATE", "time":"TIME", "room":"ROOM",
                    "type":"RESOURCE", "requester":"REQUESTER", "status":"STATUS"}
        widths = {"id":50, "date":110, "time":130, "room":110, "type":110,
                  "requester":180, "status":100}
        for col in cols:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="w")
        yscroll = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=yscroll.set)
        tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")
        rows = data if data is not None else self.bookings
        for b in sorted(rows, key=lambda x:(x.get("date",""), x.get("start_time","")), reverse=True):
            time_range = f"{b.get('start_time','')} - {b.get('end_time','')}"
            tree.insert("", "end", values=(b.get("id"), b.get("date"), time_range,
                        b.get("room"), b.get("resource_type"), b.get("requester"),
                        b.get("status", "Approved")))
        return tree

    def show_bookings(self):
        self.clear()
        self.header("All bookings", "Browse every classroom and laboratory reservation.")
        panel = tk.Frame(self.main, bg=WHITE, highlightbackground="#E4EAF2",
                         highlightthickness=1)
        panel.pack(fill="both", expand=True, padx=32, pady=(0, 20))
        bar = tk.Frame(panel, bg=WHITE)
        bar.pack(fill="x", padx=18, pady=16)
        tk.Label(bar, text=f"{len(self.bookings)} records", bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 10)).pack(side="left")
        self.button(bar, "＋  Add booking", self.show_add).pack(side="right")
        self.make_table(panel, height=14)
        actions = tk.Frame(self.main, bg=BG)
        actions.pack(fill="x", padx=32, pady=(0, 20))
        self.button(actions, "Cancel selected booking", lambda: self.cancel_from_tree(tree_ref[0]), RED).pack(side="left")
        tree_ref = [None]
        # Find the Treeview created above.
        for child in panel.winfo_children():
            for sub in child.winfo_children():
                if isinstance(sub, ttk.Treeview):
                    tree_ref[0] = sub

    def show_add(self):
        self.clear()
        self.header("Create a booking", "Enter the details below to reserve a classroom or laboratory.")
        panel = tk.Frame(self.main, bg=WHITE, highlightbackground="#E4EAF2",
                         highlightthickness=1)
        panel.pack(anchor="nw", padx=32, pady=(0, 20), fill="x")
        form = tk.Frame(panel, bg=WHITE)
        form.pack(fill="x", padx=26, pady=24)
        fields = {}
        specs = [
            ("Requester / faculty name", "requester", "entry"),
            ("Department", "department", "entry"),
            ("Resource type", "resource_type", "combo"),
            ("Room name / number", "room", "entry"),
            ("Date (YYYY-MM-DD)", "date", "entry"),
            ("Start time (HH:MM)", "start_time", "entry"),
            ("End time (HH:MM)", "end_time", "entry"),
            ("Purpose", "purpose", "entry"),
            ("Expected number of users", "capacity", "entry")
        ]
        for i, (label, key, kind) in enumerate(specs):
            r, c = divmod(i, 2)
            cell = tk.Frame(form, bg=WHITE)
            cell.grid(row=r, column=c, sticky="ew", padx=(0, 22), pady=9)
            tk.Label(cell, text=label, bg=WHITE, fg=TEXT,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 5))
            if kind == "combo":
                widget = ttk.Combobox(cell, values=["Classroom", "Lab"], state="readonly")
                widget.set("Classroom")
            else:
                widget = ttk.Entry(cell)
                if key == "date": widget.insert(0, date.today().isoformat())
                if key == "start_time": widget.insert(0, "09:00")
                if key == "end_time": widget.insert(0, "10:00")
                if key == "capacity": widget.insert(0, "30")
            widget.pack(fill="x", ipady=3)
            fields[key] = widget
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        def submit():
            values = {k: w.get().strip() for k, w in fields.items()}
            for k, v in values.items():
                if not v:
                    messagebox.showerror("Missing information", "Please complete every field.")
                    return
            error = validate_booking(values)
            if error:
                messagebox.showerror("Invalid input", error)
                return
            conflict = find_conflict(self.bookings, values)
            if conflict:
                messagebox.showerror("Booking conflict",
                    f"{values['room']} is already booked from {conflict['start_time']} to {conflict['end_time']} by {conflict['requester']}.")
                return
            new_id = next_booking_id(self.bookings)
            record = {"id":new_id, **values, "capacity":int(values["capacity"]), "status":"Approved"}
            self.bookings.append(record)
            save_data(self.bookings)
            messagebox.showinfo("Booking saved", f"Booking #{new_id} was created successfully.")
            self.show_dashboard()
        self.button(panel, "Save booking", submit).pack(anchor="w", padx=26, pady=(0, 24))

    def show_search(self):
        self.clear()
        self.header("Search bookings", "Find records by requester, room, department, purpose or date.")
        panel = tk.Frame(self.main, bg=WHITE, highlightbackground="#E4EAF2", highlightthickness=1)
        panel.pack(fill="both", expand=True, padx=32, pady=(0, 20))
        bar = tk.Frame(panel, bg=WHITE)
        bar.pack(fill="x", padx=18, pady=18)
        query = ttk.Entry(bar, width=45)
        query.pack(side="left", ipady=5)
        result_area = tk.Frame(panel, bg=WHITE)
        result_area.pack(fill="both", expand=True)
        def run_search():
            term = query.get().strip().casefold()
            if not term:
                messagebox.showwarning("Search", "Enter a keyword to search.")
                return
            found = search_bookings(self.bookings, term)
            for w in result_area.winfo_children(): w.destroy()
            tk.Label(result_area, text=f"{len(found)} matching record(s)", bg=WHITE,
                     fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=18, pady=(0, 10))
            self.make_table(result_area, found, height=13)
        self.button(bar, "Search", run_search).pack(side="left", padx=10)
        query.bind("<Return>", lambda e: run_search())

    def cancel_from_tree(self, tree):
        if tree is None:
            return
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("Select booking", "Select a booking row first.")
            return
        booking_id = int(tree.item(selected[0], "values")[0])
        self.cancel_id(booking_id)

    def cancel_id(self, booking_id):
        for b in self.bookings:
            if int(b.get("id", -1)) == booking_id:
                if b.get("status") == "Cancelled":
                    messagebox.showinfo("Already cancelled", "This booking is already cancelled.")
                else:
                    if messagebox.askyesno("Confirm cancellation", f"Cancel booking #{booking_id}?"):
                        b["status"] = "Cancelled"
                        save_data(self.bookings)
                        messagebox.showinfo("Cancelled", "Booking has been cancelled.")
                        self.show_bookings()
                return
        messagebox.showerror("Not found", "Booking ID was not found.")

    def show_reports(self):
        self.clear()
        self.header("Reports & analytics", "Understand booking activity and export your records.")
        active = [b for b in self.bookings if b.get("status", "Approved") != "Cancelled"]
        cancelled = len(self.bookings) - len(active)
        cards = tk.Frame(self.main, bg=BG)
        cards.pack(fill="x", padx=32)
        for title, value, color in [
            ("Total records", len(self.bookings), ACCENT),
            ("Active", len(active), GREEN),
            ("Cancelled", cancelled, RED),
            ("Lab bookings", sum(1 for b in active if b.get("resource_type")=="Lab"), "#8B5CF6")
        ]:
            c, _ = self.card(cards, title, value, color)
            c.pack(side="left", fill="both", expand=True, padx=(0, 12))
        panel = tk.Frame(self.main, bg=WHITE, highlightbackground="#E4EAF2", highlightthickness=1)
        panel.pack(fill="both", expand=True, padx=32, pady=24)
        tk.Label(panel, text="Booking insights", bg=WHITE, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=22, pady=(20, 10))
        if active:
            avg = sum(int(b.get("capacity", 0)) for b in active) / len(active)
            room_counts = Counter(b.get("room", "Unknown") for b in active)
            summary = f"Average expected users per active booking: {avg:.1f}\n\nMost used resources:\n"
            summary += "\n".join(f"  • {room}: {count} booking(s)" for room, count in room_counts.most_common(6))
        else:
            summary = "No active bookings yet. Add a booking or import sample data to see analytics."
        tk.Label(panel, text=summary, bg=WHITE, fg=MUTED, justify="left",
                 font=("Segoe UI", 11), lineSpacing=8).pack(anchor="w", padx=22, pady=8)
        self.button(panel, "Export CSV / TXT / Markdown reports", self.export_reports).pack(anchor="w", padx=22, pady=20)

    def export_reports(self):
        if not self.bookings:
            messagebox.showinfo("No data", "There are no bookings to export.")
            return
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        fields = ["id","requester","department","resource_type","room","date","start_time",
                  "end_time","purpose","capacity","status"]
        csv_path = REPORTS / f"bookings_{stamp}.csv"
        txt_path = REPORTS / f"bookings_{stamp}.txt"
        md_path = REPORTS / f"bookings_{stamp}.md"
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(self.bookings)
        with txt_path.open("w", encoding="utf-8") as f:
            f.write("CLASSROOM RESOURCE BOOKING REPORT\n\n")
            for b in self.bookings:
                f.write(f"#{b['id']} | {b['date']} | {b['room']} | {b['requester']} | {b['status']}\n")
        with md_path.open("w", encoding="utf-8") as f:
            f.write("# Classroom Resource Booking Report\n\n| ID | Date | Room | Requester | Status |\n|---:|---|---|---|---|\n")
            for b in self.bookings:
                f.write(f"| {b['id']} | {b['date']} | {b['room']} | {b['requester']} | {b['status']} |\n")
        messagebox.showinfo("Export complete", f"Reports saved in:\n{REPORTS}")

    def import_sample(self):
        if not SAMPLE.exists():
            messagebox.showerror("Missing file", "Sample dataset was not found.")
            return
        existing = {str(b.get("id")) for b in self.bookings}
        added = 0
        try:
            for row in import_csv(SAMPLE):
                if str(row["id"]) in existing: continue
                self.bookings.append(row); existing.add(str(row["id"])); added += 1
        except (OSError, ValueError) as exc:
            messagebox.showerror("Import failed", str(exc))
            return
        save_data(self.bookings)
        messagebox.showinfo("Sample data imported", f"{added} sample booking records added.")
        self.show_dashboard()

if __name__ == "__main__":
    import sys
    if "--cli" in sys.argv:
        from cli import run_cli
        run_cli()
    else:
        app = BookingApp()
        app.mainloop()
