# CampusBook – Classroom Resource Booking System

A Python 3.10+ classroom and laboratory reservation application. It includes a Tkinter desktop GUI and an optional menu-driven terminal interface.

## Run in VS Code
1. Extract the ZIP and open the `Classroom_Resource_Booking_GUI` folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Start the graphical interface:
   ```bash
   python main.py
   ```
   On Windows, `py main.py` also works.
4. To run the terminal interface instead:
   ```bash
   python main.py --cli
   ```

No third-party packages are required. Tkinter is included with most standard Python installations.

## Features
- Dashboard with booking totals and recent reservations
- Create classroom and lab reservations
- Detect overlapping reservations for the same room and date
- Validate date, time, resource type, text length and capacity
- Search bookings and cancel existing reservations
- JSON persistence with atomic saves and recovery of corrupted data
- Import sample records from CSV
- Export CSV, TXT and Markdown reports
- Booking summaries and room usage analytics
- CLI mode for a menu-driven terminal workflow

## Architecture
- `main.py` – Tkinter presentation layer and event handling
- `cli.py` – optional terminal presentation layer
- `booking_service.py` – reusable booking validation, conflict detection, search and analytics
- `repository.py` – JSON/CSV data access and persistence
- `tests/` – automated unit tests for core business rules

The GUI and CLI both call the same service and repository modules; business rules are not embedded in the interface widgets.

## Run automated tests
From the project folder:
```bash
python -m unittest discover -s tests -v
```
The included test suite checks validation, time overlap, adjacent bookings, cancelled records, conflict detection, IDs, search and summary calculations.

## Demo
1. Launch `python main.py`.
2. Choose **Import sample data** in the sidebar.
3. Review the dashboard and all-bookings page.
4. Add a booking that overlaps an existing room/time slot to demonstrate conflict prevention.
5. Open Reports & analytics and export reports.
6. Run the unit tests to demonstrate verified business logic.

## Project structure
```text
Classroom_Resource_Booking_GUI/
├── main.py
├── cli.py
├── booking_service.py
├── repository.py
├── README.md
├── data/
│   ├── bookings.json
│   └── sample_bookings.csv
├── reports/
└── tests/
    └── test_booking_service.py
```
