"""Business rules for Classroom Resource Booking (independent of the GUI)."""
from datetime import datetime, date
from collections import Counter


def validate_booking(values, today=None):
    today = today or date.today()
    required = ("requester", "department", "resource_type", "room", "date",
                "start_time", "end_time", "purpose", "capacity")
    for key in required:
        value = str(values.get(key, "")).strip()
        if not value:
            return f"{key.replace('_', ' ').title()} is required."
        if len(value) > 120:
            return f"{key.replace('_', ' ').title()} must be 120 characters or fewer."
        if any(ord(ch) < 32 for ch in value):
            return "Input contains unsupported control characters."
    if values["resource_type"] not in {"Classroom", "Lab"}:
        return "Resource type must be Classroom or Lab."
    try:
        day = datetime.strptime(values["date"], "%Y-%m-%d").date()
        start = datetime.strptime(values["start_time"], "%H:%M").time()
        end = datetime.strptime(values["end_time"], "%H:%M").time()
        capacity = int(values["capacity"])
    except (ValueError, TypeError):
        return "Use YYYY-MM-DD for date, HH:MM for time, and a whole number for capacity."
    if day < today:
        return "Date must be today or a future date."
    if start >= end:
        return "End time must be later than start time."
    if not 1 <= capacity <= 1000:
        return "Capacity must be between 1 and 1000."
    return None


def intervals_overlap(start_a, end_a, start_b, end_b):
    return start_a < end_b and start_b < end_a


def find_conflict(bookings, values, exclude_id=None):
    for booking in bookings:
        if exclude_id is not None and str(booking.get("id")) == str(exclude_id):
            continue
        if (booking.get("room", "").strip().casefold() == values["room"].strip().casefold()
                and booking.get("date") == values["date"]
                and booking.get("status", "Approved") != "Cancelled"
                and intervals_overlap(values["start_time"], values["end_time"],
                                      booking.get("start_time", ""), booking.get("end_time", ""))):
            return booking
    return None


def next_booking_id(bookings):
    return max((int(item.get("id", 0)) for item in bookings), default=0) + 1


def search_bookings(bookings, keyword):
    term = keyword.strip().casefold()
    if not term:
        return []
    return [item for item in bookings
            if term in " ".join(str(value) for value in item.values()).casefold()]


def booking_summary(bookings):
    active = [b for b in bookings if b.get("status", "Approved") != "Cancelled"]
    rooms = Counter(b.get("room", "Unknown") for b in active)
    return {"total": len(bookings), "active": len(active),
            "cancelled": len(bookings) - len(active),
            "average_capacity": (sum(int(b.get("capacity", 0)) for b in active) / len(active)) if active else 0,
            "most_used_rooms": rooms.most_common(6)}
