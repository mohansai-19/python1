"""Local JSON/CSV persistence layer."""
import csv
import json
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "data"
REPORTS_DIR = BASE / "reports"
DB_PATH = DATA_DIR / "bookings.json"
SAMPLE_PATH = DATA_DIR / "sample_bookings.csv"


def load_bookings(path=DB_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        save_bookings([], path)
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, list) or any(not isinstance(row, dict) for row in data):
            raise ValueError("Booking data must be a list of records")
        return data
    except (json.JSONDecodeError, OSError, ValueError):
        backup = path.with_suffix(path.suffix + ".corrupt")
        try:
            os.replace(path, backup)
        except OSError:
            pass
        save_bookings([], path)
        return []


def save_bookings(bookings, path=DB_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(bookings, indent=4, ensure_ascii=False), encoding="utf-8")
    os.replace(temp, path)


def import_csv(path=SAMPLE_PATH):
    imported = []
    with Path(path).open("r", newline="", encoding="utf-8-sig") as handle:
        for line_number, row in enumerate(csv.DictReader(handle), start=2):
            try:
                row["id"] = int(row["id"])
                row["capacity"] = int(row["capacity"])
                imported.append(row)
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError(f"Invalid sample data at row {line_number}: {exc}") from exc
    return imported
