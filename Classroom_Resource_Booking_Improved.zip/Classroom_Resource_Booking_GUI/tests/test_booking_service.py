import unittest
from datetime import date, timedelta
from booking_service import (validate_booking, intervals_overlap, find_conflict,
                             next_booking_id, search_bookings, booking_summary)

class BookingServiceTests(unittest.TestCase):
    def setUp(self):
        self.values = {"requester":"Asha", "department":"CSE", "resource_type":"Classroom",
                       "room":"A-101", "date":(date.today()+timedelta(days=1)).isoformat(),
                       "start_time":"09:00", "end_time":"10:00", "purpose":"Lecture", "capacity":"40"}

    def test_valid_booking(self): self.assertIsNone(validate_booking(self.values))
    def test_invalid_capacity(self):
        self.values["capacity"] = "0"
        self.assertIn("Capacity", validate_booking(self.values))
    def test_end_before_start(self):
        self.values["end_time"] = "08:00"
        self.assertIn("End time", validate_booking(self.values))
    def test_overlap(self): self.assertTrue(intervals_overlap("09:00", "10:00", "09:30", "11:00"))
    def test_adjacent_slots_do_not_overlap(self): self.assertFalse(intervals_overlap("09:00", "10:00", "10:00", "11:00"))
    def test_conflict_detected_case_insensitively(self):
        rows = [{**self.values, "id": 1, "room":"a-101", "status":"Approved"}]
        self.assertIsNotNone(find_conflict(rows, self.values))
    def test_cancelled_booking_is_ignored(self):
        rows = [{**self.values, "id": 1, "status":"Cancelled"}]
        self.assertIsNone(find_conflict(rows, self.values))
    def test_next_id(self): self.assertEqual(next_booking_id([{"id":2}]), 3)
    def test_search(self): self.assertEqual(len(search_bookings([{**self.values}], "asha")), 1)
    def test_summary(self):
        result = booking_summary([{**self.values, "capacity": 40}])
        self.assertEqual(result["active"], 1)
        self.assertEqual(result["average_capacity"], 40)

if __name__ == "__main__": unittest.main()
