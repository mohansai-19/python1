"""Optional menu-driven terminal interface required for console demonstrations."""
from repository import load_bookings, save_bookings
from booking_service import validate_booking, find_conflict, next_booking_id, booking_summary
from datetime import date

FIELDS = ("requester", "department", "resource_type", "room", "date", "start_time", "end_time", "purpose", "capacity")

def run_cli():
    bookings = load_bookings()
    while True:
        print("\n=== CAMPUSBOOK | RESOURCE BOOKING ===")
        print("1. Add booking\n2. List bookings\n3. Summary\n4. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            values = {key: input(f"{key.replace('_',' ').title()}: ").strip() for key in FIELDS}
            error = validate_booking(values)
            if error:
                print("Invalid booking:", error)
                continue
            conflict = find_conflict(bookings, values)
            if conflict:
                print(f"Conflict: {conflict['room']} is booked {conflict['start_time']}-{conflict['end_time']}.")
                continue
            bookings.append({"id": next_booking_id(bookings), **values, "capacity": int(values["capacity"]), "status": "Approved"})
            save_bookings(bookings)
            print("Booking saved successfully.")
        elif choice == "2":
            if not bookings: print("No bookings found.")
            for b in bookings:
                print(f"#{b.get('id')} | {b.get('date')} | {b.get('start_time')}-{b.get('end_time')} | {b.get('room')} | {b.get('requester')} | {b.get('status','Approved')}")
        elif choice == "3":
            stats = booking_summary(bookings)
            print(f"Total: {stats['total']} | Active: {stats['active']} | Cancelled: {stats['cancelled']} | Average capacity: {stats['average_capacity']:.1f}")
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Please enter 1, 2, 3 or 4.")
